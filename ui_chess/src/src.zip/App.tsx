// =========================
// App.tsx – FULL ROOM SYSTEM
// =========================

import React, { useRef, useState, useEffect, useMemo } from "react";
import { Chess } from "chess.js";
import { ChessBoard } from "@/components/ChessBoard";

import { useChessBot } from "@/hooks/useChessBot";
import { useOnlineRoom } from "@/hooks/useOnlineRoom";
import { usePlayerMove } from "@/hooks/usePlayerMove";

import { useSocket } from "@/context/SocketProvider";

import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

import { randomUUID } from "@/utils/id";
import { Switch } from "@/components/ui/switch";

const START_FEN = new Chess().fen();

export default function App() {
  const socket = useSocket();
  const gameRef = useRef(new Chess());

  // ============================
  // STATE CHÍNH
  // ============================
  const [mode, setMode] = useState<"bot" | "online">("bot");
  const [fen, setFen] = useState(START_FEN);
  const [history, setHistory] = useState([START_FEN]);
  const [historyIndex, setHistoryIndex] = useState(0);

  const [playerColor, setPlayerColor] = useState<"w" | "b">("w");
  const [onlineColor, setOnlineColor] = useState<"w" | "b" | null>(null);

  // roomId ở đây thực chất là roomName từ server
  const [roomId, setRoomId] = useState("");
  const [connected, setConnected] = useState(false);

  const [lastMove, setLastMove] = useState<any>(null);
  const [capturedPiece, setCapturedPiece] = useState<any>(null);

  const [botDepth, setBotDepth] = useState(3);
  const [botThinking, setBotThinking] = useState(false);
  const [deadKingSquare, setDeadKingSquare] = useState<string | null>(null);
  const [isAnimating, setIsAnimating] = useState(false);

  const [roomList, setRoomList] = useState<any[]>([]);
  const [newRoomName, setNewRoomName] = useState("");
  const [gameFinished, setGameFinished] = useState(false);
  const [popup, setPopup] = useState({
	  type: null,        // "leaveConfirm" | "drawConfirm" | "info"
	  message: "",
	  onAccept: null,
	  onReject: null,
	});



  const viewColor: "w" | "b" =
    mode === "bot" ? playerColor : onlineColor ?? "w";

  const isJoiningRef = useRef(false);
  const lastLocalMoveIdRef = useRef<string | null>(null);

  // ============================
  // Popup settings
  // ============================
  const [showSettings, setShowSettings] = useState(true);

  // ============================
  // Đồng bộ gameRef với FEN để vẽ board
  // ============================
  const displayGame = useMemo(() => {
    const g = new Chess();
    try {
      g.load(fen);
    } catch (e) {
      console.error("Lỗi load fen:", fen, e);
    }
    return g;
  }, [fen]);

  // ============================
  // PUSH STATE (update local + emit socket nếu online)
  // ============================
  const pushState = (
    newFen: string,
    newHistory: string[],
    newIndex: number,
    emit = true,
    lastMoveSend: any = null
  ) => {
    const moveId = randomUUID();
    lastLocalMoveIdRef.current = moveId;

    setFen(newFen);
    setHistory(newHistory);
    setHistoryIndex(newIndex);

    // ⭐ Quan trọng: server.js nhận { roomName } chứ không phải { roomId }
    if (mode === "online" && emit && socket && roomId) {
      socket.emit("game:state", {
        roomName: roomId, // ✅ match server.js
        fen: newFen,
        history: newHistory,
        historyIndex: newIndex,
        lastMove: lastMoveSend,
        moveId,
      });
    }
  };

  // ============================
  // HOOK PLAYER MOVE
  // ============================
  const {
    selectedSquare,
    legalTargets,
    movingPiece,
    movingPath,
    movingStep,
    hidePiece,
    handleSquareClick,
    resetAnimation,
  } = usePlayerMove({
    fen,
    gameRef,
    history,
    historyIndex,
    pushState,
    mode,
    playerColor,
    onlineColor,
    setLastMove,
    onMoveApplied: (g: Chess) => {
      if (g.isCheckmate()) {
        const loser = g.turn();
        let dead: string | null = null;
        const b = g.board();
        for (let r = 0; r < 8; r++)
          for (let c = 0; c < 8; c++) {
            const p = b[r][c];
            if (p && p.type === "k" && p.color === loser) {
              dead = "abcdefgh"[c] + (8 - r);
            }
          }
        setDeadKingSquare(dead);
      }
    },
    setIsAnimating,
    isJoiningRef,
  });

  // ============================
  // HOOK BOT
  // ============================
  useChessBot({
    mode,
    playerColor,
    botDepth,
    fen,
    game: gameRef.current,
    history,
    historyIndex,
    setFen,
    setHistory,
    setHistoryIndex,
    botThinking,
    setBotThinking,
    setLastMove,
  });

  // ============================
  // ONLINE HOOK
  // ============================
  useOnlineRoom({
    mode,
    socket,
    roomId,
    setConnected,
    setOnlineColor,
    setFen,
    setHistory,
    setHistoryIndex,
    setLastMove,
    lastLocalMoveIdRef,
    resetAnimation,
    isJoiningRef,
  });

  // ============================
  // LẤY DANH SÁCH PHÒNG
  // ============================
  const loadRooms = () => {
    if (socket) socket.emit("rooms:list");
  };

  // ============================
  // SOCKET CLIENT SIDE HANDLERS
  // ============================
  useEffect(() => {
    if (!socket) return;

    // Nhận danh sách phòng từ server
    socket.on("rooms:list:response", (list) => {
      setRoomList(list || []);
    });

    // Server yêu cầu client refresh list
    socket.on("rooms:update", () => {
      socket.emit("rooms:list");
    });

    // Phòng full
    socket.on("room:full", () => {
	  setPopup({
		type: "info",
		message: "Phòng đã đủ 2 người!",
		onAccept: () => setPopup({ type: null })
	  });
	});

	socket.on("rooms:clear:done", ({ removed }) => {
	  setPopup({
		type: "info",
		message: `Đã xoá ${removed} phòng trống.`,
		onAccept: () => setPopup({ type: null }),
	  });
	});



    // Tạo phòng xong
    socket.on("room:created", ({ roomName }) => {
	  setPopup({
		type: "info",
		message: `Tạo phòng thành công: ${roomName}`,
		onAccept: () => {
		  setPopup({ type: null });
		  setRoomId(roomName);
		  socket.emit("room:join", { roomName });
		  setShowSettings(false);
		},
	  });
	});
	socket.on("room:force-leave", () => {
	  resetBoardState();   // reset bàn cờ
	  setRoomId("");       // xoá room
	  setOnlineColor(null);
	  setGameFinished(false);

	  setPopup({
		type: "info",
		message: "Phòng đã đóng do người chơi thoát!",
		onAccept: () => setPopup({ type: null }),
	  });
	});


    // Đối thủ rời phòng (sau khi được approve)
   socket.on("room:left", () => {
	  resetFullGame();     // reset toàn bộ
	  setRoomId("");
	  setOnlineColor(null);

	  setPopup({
		type: "info",
		message: "Bạn đã rời phòng.",
		onAccept: () => setPopup({ type: null }),
	  });
	});
	
	socket.on("room:opponent-left", () => {
	  resetMatchOnly();  // GIỮ màu, chỉ reset bàn mới

	  setPopup({
		type: "info",
		message: "Đối thủ đã rời phòng!",
		onAccept: () => setPopup({ type: null }),
	  });
	});





    // Yêu cầu rời phòng (từ đối thủ)
    socket.on("room:leave:confirm", () => {
	  setPopup({
		type: "leaveConfirm",
		message: "Đối thủ xin rời phòng. Bạn có chấp nhận?",
		onAccept: () => {
		  socket.emit("room:leave:approved", { roomName: roomId });
		  setPopup({ type: null });
		},
		onReject: () => {
		  socket.emit("room:leave:denied", { roomName: roomId });
		  setPopup({ type: null });
		},
	  });
	});


    socket.on("room:leave:denied", () => {
	  setPopup({
		type: "info",
		message: "Đối thủ không đồng ý cho bạn rời phòng.",
		onAccept: () => setPopup({ type: null }),
	  });
	});


    // CẦU HÒA
    socket.on("draw:offer:received", () => {
	  setPopup({
		type: "drawConfirm",
		message: "Đối thủ đề nghị hòa. Bạn có chấp nhận?",
		onAccept: () => {
		  socket.emit("draw:accept", { roomName: roomId });
		  resetMatchOnly();
		  setPopup({ type: null });
		},
		onReject: () => {
		  socket.emit("draw:reject", { roomName: roomId });
		  setPopup({ type: null });
		},
	  });
	});


   socket.on("draw:accepted", () => {
	  setPopup({
		type: "info",
		message: "Ván đấu kết thúc: Hòa!",
		onAccept: () => {
		  resetMatchOnly();
		  setPopup({ type: null });
		},
	  });
	});


    socket.on("draw:rejected", () => {
	  setPopup({
		type: "info",
		message: "Đối thủ từ chối hòa.",
		onAccept: () => setPopup({ type: null }),
	  });
	});


    return () => {
      socket.off("rooms:list:response");
      socket.off("rooms:update");
      socket.off("room:full");
      socket.off("room:created");
      socket.off("room:left");
      socket.off("room:leave:confirm");
      socket.off("room:leave:denied");
      socket.off("draw:offer:received");
      socket.off("draw:accepted");
      socket.off("draw:rejected");
	  socket.off("rooms:clear:done");

    };
  }, [socket, roomId]);

  // ============================
  // RESET FULL BOARD
  // ============================
  const resetBoardState = () => {
    const g = new Chess();
    const f = g.fen();
	
	// ❗ Quan trọng
    gameRef.current = g;
    setFen(f);
    setHistory([f]);
    setHistoryIndex(0);

    setOnlineColor(null);
    setDeadKingSquare(null);
    setLastMove(null);
    setCapturedPiece(null);
    setIsAnimating(false);
	setGameFinished(false);


    resetAnimation?.();
  };
  
   const resetFullGame = () => {
	  const g = new Chess();
	  const f = g.fen();

	  setFen(f);
	  setHistory([f]);
	  setHistoryIndex(0);

	  setOnlineColor(null); // ❗ chỉ reset khi rời phòng
	  setDeadKingSquare(null);
	  setLastMove(null);
	  setCapturedPiece(null);
	  setIsAnimating(false);
	  resetAnimation?.();
	};
	
	
	const resetMatchOnly = () => {
	  const g = new Chess();
	  const f = g.fen();

	  // ❗ reset Chess instance để cả 2 phía sync lại đúng game thật
	  gameRef.current = g;

	  setFen(f);
	  setHistory([f]);
	  setHistoryIndex(0);

	  // Giữ nguyên màu của người chơi online
	  setDeadKingSquare(null);
	  setLastMove(null);
	  setCapturedPiece(null);
	  setIsAnimating(false);

	  resetAnimation?.();
	};




  // ============================
  // RỜI PHÒNG (nút 🚪) – gửi request
  // ============================
  const handleLeaveRoom = () => {
    if (socket && roomId) {
      socket.emit("room:leave:request", { roomName: roomId });
      alert("Đã gửi yêu cầu rời phòng – chờ đối thủ chấp nhận...");
    }
  };

  // ============================
  // UNDO / REDO / RESET
  // ============================
  const handleUndo = () => {
    if (historyIndex === 0) return;
    const idx = historyIndex - 1;
    pushState(history[idx], history, idx);
  };

  const handleRedo = () => {
    if (historyIndex >= history.length - 1) return;
    const idx = historyIndex + 1;
    pushState(history[idx], history, idx);
  };

  const handleReset = () => resetBoardState();

  const currentTurn = displayGame.turn();

  // =====================================
  // RENDER
  // =====================================
  return (
    <>
      {/* Nút Settings */}
      <button
        onClick={() => setShowSettings(true)}
        className="fixed bottom-6 right-6 w-14 h-14 rounded-full bg-slate-800 hover:bg-slate-700 border border-slate-600 shadow-lg shadow-black/40 flex items-center justify-center text-3xl"
      >
        ⚙
      </button>

     {/* Nút Thoát Phòng – chỉ hiện khi đang trong ván và chưa kết thúc */}
		{mode === "online" && roomId && !gameFinished && (
		  <button
			onClick={() => {
			  setPopup({
				type: "info",
				message: "Đã gửi yêu cầu rời phòng — chờ đối thủ chấp nhận...",
				onAccept: () => setPopup({ type: null })
			  });

			  socket.emit("room:leave:request", { roomName: roomId });
			}}

			className="fixed bottom-6 right-24 w-14 h-14 rounded-full bg-red-700 hover:bg-red-600 shadow-lg flex items-center justify-center text-white text-xl"
		  >
			🚪
		  </button>
		)}


     {/* Nút Cầu Hòa – chỉ hiện khi đang trong ván & chưa kết thúc */}
		{mode === "online" && roomId && !gameFinished && history.length > 1 && (
		  <button
			onClick={() => {
			  setPopup({
				type: "info",
				message: "Đã gửi lời đề nghị hòa. Chờ đối thủ phản hồi…",
				onAccept: () => setPopup({ type: null })
			  });

			  socket.emit("draw:offer", { roomName: roomId });
			}}

			className="fixed bottom-6 right-44 w-14 h-14 rounded-full bg-yellow-700 hover:bg-yellow-600 shadow-lg flex items-center justify-center text-white text-xl"
		  >
			🤝
		  </button>
		)}



      <div className="min-h-screen bg-slate-950 text-slate-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-5xl bg-slate-900/80 border-slate-700">
          <CardHeader>
            <CardTitle className="flex justify-between">
              ♟ React Chess – Online / Bot
              <span className="text-xs text-slate-400">
                {mode === "bot" ? "Chơi với BOT" : "Chơi Online"}{" "}
                {mode === "online" && roomId && `• Phòng: ${roomId}`}
              </span>
            </CardTitle>
          </CardHeader>

          <CardContent className="grid grid-cols-1 md:grid-cols-[2fr,1fr] gap-6">
            {/* BOARD */}
            <div className="flex flex-col items-center gap-4">
              <ChessBoard
                board={displayGame.board()}
                selectedSquare={selectedSquare}
                legalTargets={legalTargets}
                lastMove={lastMove}
                capturedPiece={capturedPiece}
                movingPiece={movingPiece}
                movingPath={movingPath}
                movingStep={movingStep}
                hidePiece={hidePiece}
                deadKingSquare={deadKingSquare}
                viewColor={viewColor}
                onClick={handleSquareClick}
              />

              <div className="flex gap-2">
                <Button onClick={handleUndo}>Undo</Button>
                <Button onClick={handleRedo}>Redo</Button>
                <Button onClick={handleReset}>Reset</Button>
              </div>

              <div className="text-sm text-slate-300">
                Lượt hiện tại: {currentTurn === "w" ? "Trắng" : "Đen"}{" "}
                {mode === "bot" && botThinking && " – BOT đang tính…"}
              </div>
            </div>

            {/* PANEL PHẢI – có thể để trạng thái, gợi ý, ... */}
            <div className="space-y-3 text-sm">
              <div className="p-3 rounded border border-slate-700">
                <div className="font-semibold mb-1">Trạng thái</div>
                <div>Chế độ: {mode === "bot" ? "BOT" : "ONLINE"}</div>
                {mode === "online" && (
                  <>
                    <div>Socket: {connected ? "Đã kết nối" : "Mất kết nối"}</div>
                    <div>Màu của bạn: {onlineColor === "w" ? "Trắng" : onlineColor === "b" ? "Đen" : "Chưa xác định"}</div>
                    <div>Phòng hiện tại: {roomId || "Chưa vào phòng"}</div>
                  </>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* POPUP SETTINGS */}
      <Dialog
        open={showSettings}
        onOpenChange={(open) => {
          // Nếu chưa chọn mode mà cố tắt popup thì chặn (hiện tại mode mặc định là "bot" nên chỗ này chủ yếu cho tương lai)
          if (!open && !mode) return;
          setShowSettings(open);
        }}
      >
        <DialogContent className="bg-slate-900 text-white border-slate-700 max-w-sm">
          <DialogHeader>
            <DialogTitle>⚙ Cài đặt</DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            {/* CHỌN CHẾ ĐỘ */}
            <div>
              <div className="mb-1">Chế độ chơi</div>
               <div className="flex items-center justify-between bg-slate-800 p-3 rounded-md border border-slate-700">
					<span className={mode === "bot" ? "text-green-400 font-semibold" : "text-slate-400"}>
					  BOT
					</span>

					<Switch
					  checked={mode === "online"}
					  onCheckedChange={(checked) => {
						const val = checked ? "online" : "bot";

						setMode(val);

						if (val === "bot") {
						  setRoomId("");
						  setOnlineColor(null);
						  resetBoardState(); // Giữ logic reset như ban đầu
						}
					  }}
					/>

					<span className={mode === "online" ? "text-green-400 font-semibold" : "text-slate-400"}>
					  ONLINE
					</span>
				  </div>
            </div>

            {/* ONLINE MODE SETTINGS */}
            {mode === "online" && (
              <div className="space-y-4">
                {/* Nhập tên phòng */}
                <div>
                  <div className="mb-1">Tên phòng</div>
                  <Input
                    value={newRoomName}
                    onChange={(e) => setNewRoomName(e.target.value)}
                    placeholder="Nhập tên phòng..."
                    className="bg-slate-800 text-white"
                  />
                </div>

                {/* Tạo phòng */}
                <Button
                  className="w-full bg-green-700 hover:bg-green-600"
                  onClick={() => {
                    if (!newRoomName.trim()) {
                      alert("Vui lòng nhập tên phòng!");
                      return;
                    }
                    socket?.emit("room:create", { name: newRoomName.trim() });
                  }}
                >
                  ➕ Tạo Phòng Mới
                </Button>
				
				<Button
				  className="w-full bg-red-700 hover:bg-red-600"
				  onClick={() => {
					if (confirm("Bạn có chắc muốn xoá tất cả phòng trống?")) {
					  socket.emit("rooms:clear");
					}
				  }}
				>
				  🗑 Xóa tất cả phòng trống
				</Button>


                {/* Load danh sách phòng */}
                <Button
                  className="w-full bg-blue-700 hover:bg-blue-600"
                  onClick={loadRooms}
                >
                  🔄 Tải Danh Sách Phòng
                </Button>

                {/* Danh sách phòng */}
                <div className="max-h-72 overflow-y-auto space-y-2 pr-1">
                  {roomList.length === 0 && (
                    <div className="text-center text-slate-400 text-sm">
                      Không có phòng nào
                    </div>
                  )}

                  {roomList.map((room) => {
                    const name = room.roomName;
                    return (
                      <div
                        key={name}
                        className="p-3 border border-slate-700 rounded flex justify-between items-center"
                      >
                        <div>
                          <div className="text-sm font-semibold">{name}</div>
                          <div className="text-xs text-slate-400">
                            Người chơi: {room.players}/2
                          </div>
                        </div>

                        <Button
                          disabled={room.players >= 2}
                          onClick={() => {
                            setRoomId(name);
                            socket?.emit("room:join", { roomName: name });
                            setShowSettings(false);
                          }}
                        >
                          Tham gia
                        </Button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-end pt-4">
            <Button onClick={() => setShowSettings(false)}>Đóng</Button>
          </div>
        </DialogContent>
      </Dialog>
	 <Dialog
		  open={popup.type !== null}
		  onOpenChange={() => {}} // không cho tự đóng
		>
		  <DialogContent
			className="bg-slate-900 text-white border border-slate-700 hide-close"
			onInteractOutside={(e) => e.preventDefault()}   // không cho click ra ngoài
			onEscapeKeyDown={(e) => e.preventDefault()}     // không cho ESC
		  >
			<DialogHeader>
			  <DialogTitle>
				{popup.type === "leaveConfirm" && "Xin rời phòng"}
				{popup.type === "drawConfirm" && "Lời đề nghị hòa"}
				{popup.type === "info" && "Thông báo"}
			  </DialogTitle>
			</DialogHeader>

			<div className="py-4 text-center">{popup.message}</div>

			<div className="flex justify-center gap-4 pt-4">
			  {popup.type !== "info" && (
				<Button
				  variant="secondary"
				  className="bg-red-700"
				  onClick={() => popup.onReject?.()}
				>
				  Từ chối
				</Button>
			  )}

			  <Button
				className="bg-green-700"
				onClick={() => popup.onAccept?.()}
			  >
				Đồng ý
			  </Button>
			</div>
		  </DialogContent>
		</Dialog>


    </>
  );
}
